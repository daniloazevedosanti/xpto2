ALTER TABLE clientes ADD CONSTRAINT fk_idEndereco FOREIGN KEY (codEndereco) REFERENCES endereco (id) ;

ALTER TABLE endereco ADD CONSTRAINT fk_idCliente FOREIGN KEY (codCliente) REFERENCES clientes (id) ;
CREATE TABLE movimentacoes (
  id number(10) NOT NULL,
  tipo varchar2(10) NOT NULL,
  idCliente number(10) DEFAULT NULL,
  contaOrigem number(10) NOT NULL,
  valor binary_double NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE movimentacoes_seq START WITH 15 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER movimentacoes_seq_tr
 BEFORE INSERT ON movimentacoes FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT movimentacoes_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/
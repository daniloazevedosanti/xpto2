CREATE TABLE contas (
  id number(10) NOT NULL,
  numero number(10) NOT NULL,
  saldo binary_double NOT NULL,
  idCliente number(10) DEFAULT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE contas_seq START WITH 5 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER contas_seq_tr
 BEFORE INSERT ON contas FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT contas_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
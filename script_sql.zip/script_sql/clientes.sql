CREATE TABLE clientes (
  id number(10) NOT NULL,
  nome varchar2(45) NOT NULL,
  documento varchar2(20) NOT NULL,
  tipo varchar2(2) NOT NULL,
  telefone varchar2(20) NOT NULL,
  codEndereco number(10) DEFAULT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE clientes_seq START WITH 3 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER clientes_seq_tr
 BEFORE INSERT ON clientes FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT clientes_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
CREATE TABLE endereco (
  id number(10) NOT NULL,
  enderecoCompleto varchar2(100) NOT NULL,
  codCliente number(10) DEFAULT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE endereco_seq START WITH 3 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER endereco_seq_tr
 BEFORE INSERT ON endereco FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT endereco_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/